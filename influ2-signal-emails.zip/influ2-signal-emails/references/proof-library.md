# Proof Library

Emails may name only the customers below, may claim only what's listed for each, and may cite only the figures listed here. Every claim here was checked against a case study, a customer record, or the account team. If a draft needs a claim that isn't here, leave it out.

## Approved proof

### Werner

- **Who they are:** one of the largest truckload carriers in the US. Outpost is Werner's gate automation partner across its terminals.
- **Fits:** fleets (truckload, LTL, intermodal, courier), carriers, and any segment where a records, data, or security claim backs up the solution.
- **Approved claims** (from the published quote by Ryan Gass, VP of Terminal Management, on outpost.us):
  - Werner uses it at its terminals.
  - Werner's VP of Terminal Management says it keeps their equipment more secure.
  - Werner's VP of Terminal Management says it gives them cleaner data and faster terminal throughput.
  - Werner's VP of Terminal Management says their drivers get through faster and their teams have better visibility.
- **Don't claim:** labor savings, fewer guards, or cost reductions at Werner. Don't cite automatic gate-opening rates or other Werner metrics. Don't name Ryan Gass in an email; say "Werner's VP of Terminal Management."

### United States Cold Storage

- **Who they are:** one of North America's largest refrigerated warehousing companies.
- **Fits:** cold chain, grocery and food, CPG and food and beverage, and 3PLs. It's the preferred proof for USCS competitors, such as other cold storage providers like Americold and Lineage.
- **Approved claims:**
  - It checks for seals and captures DOT and container numbers on every arriving truck.
  - Staff verify every arrival from inside, so no one walks the lanes.
  - They get faster throughput and fewer manual interventions at the gate.
  - It keeps their gate running reliably without adding headcount.
- **Approved claims from the published quote** (Mitch Harper, Area General Manager, in Outpost's second-generation launch announcement on outpost.us). Emails can echo these as "United States Cold Storage's Area General Manager says...":
  - It gives his team real-time visibility into gate activity.
  - It keeps their gate running reliably without adding headcount or complexity.
  - They're seeing faster throughput and fewer manual interventions.
- **Don't claim:** that it verifies every exit (the deployment covers arrivals), that it runs at multiple USCS facilities, or that drivers check in at a kiosk there. Don't cite daily gate event counts or rollout timelines. Don't name Mitch Harper in an email; say "United States Cold Storage's Area General Manager." Don't echo "closing that gap" from the quote, since "gap" is a banned word.

### Skechers

- **Who they are:** a global footwear retailer. Skechers chose Outpost for its distribution center gates. The deployment isn't live yet, so Skechers is a conservative proof point.
- **Fits:** retail and general merchandise, and as part of the customer list. Fine to use with Skechers competitors, including other footwear and apparel retailers.
- **Approved claims:**
  - "Retailers like Skechers chose it for their distribution center gates."
  - Skechers in the customer list sentence below.
- **Don't claim:** that Skechers uses it today, that it reduced fraudulent pickups, that it streamlined operations, or any other result.

## Published Outpost figures

These figures are published on outpost.us. Use the wording as written. They describe Outpost customers overall, so never present one as a named customer's result.

- "Tested across 4+ million live gate events"
- "98% of gate events are self-serviced, with no intercom assistance needed."
- "A single prevented misdispatch saves $250,000 on average."
- "Kiosks install in as little as one day."
- Your team or Outpost's remote operators step in 24/7.
- Drivers check in in their own language, with no app to download.

## Product claims that depend on the customer's setup

Some features are turned on per customer. Never write them as if every gate uses them.

- License scanning is optional. Say Outpost Gate Automation "can scan the driver's license," never that it scans every license.
- Dock directions need a connection to the customer's TMS, YMS, WMS, or other system.
- Don't assume the prospect staffs the gate 24/7, or cite costs or times based on 24/7 staffing.

## The customer list sentence

Use at most once per sequence, when a single named proof doesn't fit the segment or angle:

"Carriers like Werner, retailers like Skechers, and cold storage providers like United States Cold Storage chose Outpost for their gates."

## Never name

- **Outpost's own truck terminals.** Never mention them, in any segment. Many prospects, including 3PLs, could read them as competition.
- **Hub Group.** Not a public reference customer. Don't name it or describe it anonymously.
- **Allen Distribution.** Not cleared to name.
- **Schneider, Exol, EV Realty, or any other customer** not listed above.
- **Prospects, partners, or vendors.**

Don't use anonymous proof ("a national carrier," "a leading retailer"). Use a named customer from this file.

## Match proof to segment

Use the company's OGA Segment and Subsegment. Each angle in `ad-angles.md` lists a preferred proof. When it doesn't fit the segment, swap in the best match here.

| OGA Segment | Subsegment | First choice | Second choice |
|---|---|---|---|
| Retail / Grocery | General Merchandise | Skechers | Customer list |
| Retail / Grocery | Grocery / Food | United States Cold Storage | Customer list |
| 3PL | Cold Chain | United States Cold Storage | Werner |
| 3PL | Non-Cold | United States Cold Storage | Werner |
| Fleet | TL / IM / Courier, LTL, Equipment Lessor | Werner | Customer list |
| Shipper | CPG / Food & Bev | United States Cold Storage | Customer list |
| Shipper | Industrial | Customer list | Werner |
| Rail & Marine | any | Werner | Customer list |
| Unknown | — | Customer list | Werner |

Don't repeat the same proof sentence across the three emails. The same customer can appear twice if the claims differ.
