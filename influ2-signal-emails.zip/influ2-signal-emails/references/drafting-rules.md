# Drafting Rules

These rules apply to every email the skill writes. When a rule here conflicts with an example anywhere else, the rule wins.

## What the sequence adds, and what the skill writes

The HubSpot sequence puts the greeting above each body ("{First Name}," with "Hello," when the first name is missing) and the rep's signature below it. The skill writes only the subject and the body. Never write a greeting, a sign-off, a name at the end, or a signature.

## Structure

**Email 1**

1. **The question.** The angle's approved question from `ad-angles.md`. For Security angles that end with a cost, use the ending that fits the contact's role (see `roles.md`).
2. **Who we are, how it answers the question, then proof.** "I'm [Gate Owner first name] from Outpost. We automate the gate check-in process, [the angle's solution]." The solution answers the exact question in paragraph 1. Then one proof sentence from `proof-library.md` that backs up that solution.
3. **One yes/no offer.** The angle's offer, as a short question they can answer with yes.

**Emails 2 and 3**

1. **The question** for that email's angle.
2. **How it answers the question, then proof.** Open with "Outpost Gate Automation" linked to the persona's page, followed directly by the angle's solution, then one proof sentence.
3. **One yes/no offer.**

The proof can sit at the end of paragraph 2 or in its own paragraph. Three or four paragraphs total.

## Writing rules

- Under 100 words per body. No sentence over 20 words, except the approved questions in `ad-angles.md`, which are used as written, and Email 1's "We automate the gate check-in process, ..." sentence, which can run to 22.
- No semicolons. No em dashes, en dashes, or hyphens used as dashes.
- Exactly one link per email: "Outpost" in Email 1's intro, or "Outpost Gate Automation" at the start of paragraph 2 in Emails 2 and 3. It always points to the persona's landing page.
- Two questions per email: the opening question and the offer. No others.
- Short, declarative sentences. Contractions are fine.
- Say what Outpost checks specifically: drivers, trucks, tractors, trailers, seals, DOT numbers, container numbers. Never "verifies everything" or "secures your gate."
- Each email in the sequence takes a different angle and a different offer. Don't reuse the same question, solution sentence, or proof sentence across the three emails. The customer list sentence can appear once per sequence.

## Never

- Never reference the ad, the landing page, the click, a visit, or anything that suggests their activity was tracked. No "saw you looked into," "noticed your interest," "following up on," or "came across."
- Never make an assumption about the recipient, their company, or their gate. The opening question asks how they work. Nothing in the email tells them what happens at their facility.
- Never open with a statement about their industry, a statistic, or a generalization about "most companies."
- Never close with an either-or question ("...today, or still manual?").
- Never write "this, not that" or "X instead of Y" contrasts, "It's not X, it's Y," or "not just X."
- Never give a thing a person's actions or needs. Trucks, trailers, records, gates, data, claims, and systems don't "need," "know," "want," or "keep up." People and Outpost Gate Automation do things. Write "when a driver needs extra help," never "when a truck needs a person." Before writing to HubSpot, check every "needs" in the body and make sure its subject is a person.
- Never use build-up framings ("The key is...," "What makes the difference is...").
- Never use hyperbole or soft verbs: revolutionary, game-changing, seamless, robust, powerful, cutting-edge, empowers, streamlines, transforms, unlocks.
- Never mention peak season, holidays, or the time of year. These emails are evergreen.
- Never name a customer, claim a result, or cite a figure that isn't in `proof-library.md`.
- Never write a feature that depends on the customer's setup as if every gate uses it (see `proof-library.md`).
- Never mention Outpost's own truck terminals or yards.

**Banned words and phrases:** gap, on trust, airtight, gate-level, blind spot, AI, platform, security posture, fictitious, retyping, rekeying, gate transactions, Gatekeeper.

**Required wording:**
- Outpost automates the check-in process. Never write that drivers "check themselves in" or "let themselves in." It reads as lax security to a security buyer.
- Describe equipment checks in plain words: "reads equipment IDs," "makes sure trucks are hauling the right trailers," "confirms seals are present." Never "pairing" or "matches each pairing to the planned move."
- Commercial terms are two separate points, and both stay: "There's no upfront equipment cost" (no capital expense) "and billing starts once it's live and accepted" (no cost until it works).
- Tie the question to the contact's operation with "your facilities" or "your facility gates" where the approved question uses it.
- "Fraudulent pickups," never "fictitious pickups."
- "Manual data entry," never "retyping" or "rekeying."
- "TMS, YMS, WMS, or other system" when naming the systems Outpost sends data to.
- Outpost checks that a seal is present. It never reads seal numbers.
- Gate dwell is the pain. Say "dwell," never "wait times." "Detention" appears only in the claim that gate timestamps help settle detention disputes.
- The offer is a natural question a person would write ("Want me to send you a sample gate record from a pickup?"). Never "Reply 'yes'" or other scripted calls to action.

## Subject lines

- Use the angle's subject from `ad-angles.md` as written, e.g. "Gate guards at Hormel facilities" or "Gate dwell at Hormel facilities." A subject hints at the problem and stays open enough to make them curious. It never spells out the whole pitch.
- Use the friendly company name (see SKILL.md run step 5), followed by "facilities." If none exists, use "your facilities."
- Sentence case or title case. Never all lowercase.
- Under 60 characters where the company name allows.
- No tokens, no question marks, no "Re:", no "quick question," no exclamation points.

## HTML format for the body properties

The body properties are rich text, so write the body as HTML. HubSpot renders it inside the sequence email.

- Wrap each paragraph in `<p>` and `</p>`. No `<br>` for paragraph breaks.
- The one link is `<a href="URL">Outpost</a>` in Email 1, or `<a href="URL">Outpost Gate Automation</a>` in Emails 2 and 3.
- No other tags: no headings, bold, italics, lists, images, styles, classes, or inline CSS.
- Use plain apostrophes and quotation marks. Write an ampersand in a company name as `&amp;`.

Example body for Email 1:

```html
<p>When a truck shows up for a pickup at your facilities, how does your team confirm the driver and equipment before the load is gone?</p>
<p>I'm Greg from <a href="https://outpost.us/gate-automation-for-security/">Outpost</a>. We automate the gate check-in process, verifying the driver, truck, and trailer against the planned pickup. If anything doesn't match, the truck is held at the gate before the load leaves. Werner's VP of Terminal Management says it keeps their equipment more secure.</p>
<p>Want me to send you a sample gate record from a pickup?</p>
```

## The check

Run this on every email before writing to HubSpot. Count words and sentence lengths on the text with the HTML tags removed. Fix and recheck anything that fails.

1. Body is under 100 words, and no sentence is over 20 words except the approved opening question and Email 1's intro sentence (up to 22).
2. No semicolons, em dashes, en dashes, or hyphens used as dashes.
3. No banned words or phrases.
4. No mention of Outpost's own truck terminals or yards.
5. Opens with the angle's approved question, with the role ending where the angle uses one.
6. Email 1 introduces the Gate Owner by first name ("I'm [name] from Outpost. We automate the gate check-in process, ..."). Emails 2 and 3 open paragraph 2 with "Outpost Gate Automation."
7. Paragraph 2 answers the opening question, using only the angle's solution.
8. Exactly one link, to the right persona's landing page.
9. Proof uses only customers, claims, and figures from `proof-library.md`, fits the contact's segment, and isn't repeated from another email in the sequence.
10. Ends with one yes/no offer, written the way a person would ask it.
11. No assumption about the recipient, no reference to the ad, page, click, or tracking, and no time-of-year language.
12. No greeting, sign-off, or signature in the body.
13. Subject matches the angle's subject in `ad-angles.md`, uses the friendly company name, isn't all lowercase, and has no tokens.
14. Body is valid HTML using only `<p>` and one `<a href>`.
15. No thing is the subject of "needs," "wants," or "knows." No "check themselves in," "pairing," or "wait times."
