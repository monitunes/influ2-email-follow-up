# Ad Angles

Each contact gets three emails. Email 1 follows the ad they clicked. Emails 2 and 3 cover the persona's other angles. This file says how to pick the persona and angles, and what each angle says.

Each angle has an approved opening question, a solution that answers it, a proof point, an offer, and a subject. The questions ask how the contact's team works, so they never assume anything about the contact's gate. Write the rest fresh for each contact, using only what the angle and `proof-library.md` say.

## Pick the persona and angle

Work down this list and stop at the first one that gives an answer.

1. **The ad they clicked.** Use the ad named in the Influ2 engagement detail, or the contact's `last_clicked_creative_name` in HubSpot. Match it against the table below (HubSpot stores the names in lowercase).
2. **The Influ2 program they're in.** Security program `20402660-8efb-4a3b-9377-c976cde93d82` → Security, with no ad recorded. Operations program `29f29f60-8cf3-4992-b7ef-44ae1fa13790` → Operations, with no ad recorded. HubSpot's `influ2_program` can stand in if Influ2 doesn't return the program.
3. **The contact's `oga_persona`.** "Security / Asset Protection / Loss Prevention" → Security, no ad recorded. "Operations / Transportation" → Operations, no ad recorded.
4. **None of the above, or the last click was a Terminals ad and the contact is in neither OGA program.** It's not an OGA signal. Skip it.

If the contact clicked ads from both personas, follow the most recent click.

| Ad (creative name in HubSpot) | Persona | Email 1 | Email 2 | Email 3 |
|---|---|---|---|---|
| oga - ai.2 security - deceptive pickup | Security | S1 | S2 | S3 |
| oga - ai.3 security - authorize every exit | Security | S2 | S1 | S3 |
| oga - ai.1 security - verify every asset | Security | S3 | S1 | S2 |
| Security, no ad recorded | Security | S1 | S2 | S3 |
| oga - aii.5 ops - costs | Operations | O1 | O2 | O3 |
| oga - aii.2 ops - misdispatch | Operations | O2 | O1 | O3 |
| oga - aii.4 ops - throughput | Operations | O3 | O1 | O2 |
| oga - aii.1 ops - coverage | Operations | O4 | O2 | O3 |
| oga - aii.3 ops - visibility | Operations | O5 | O1 | O2 |
| Operations, no ad recorded | Operations | O1 | O2 | O3 |

The fallbacks are the most-clicked ad for each persona: Deceptive Pickup for Security and Costs for Operations.

Security emails link `https://outpost.us/gate-automation-for-security/`. Operations emails link `https://outpost.us/gate-automation-for-operations/`.

## How Email 1 differs from Emails 2 and 3

- **Email 1** introduces the rep and goes straight to the solution: "I'm [Gate Owner first name] from Outpost. We automate the gate check-in process, [the angle's solution]." "Outpost" is linked to the persona's page.
- **Emails 2 and 3** skip the introduction. Paragraph 2 opens with "Outpost Gate Automation," linked to the persona's page, followed directly by the angle's solution.

---

## Security angles

### S1. Fraudulent pickups

- **What the ad said:** Is your facility safe from pickup fraud? Thieves show up with credible paperwork. Outpost verifies drivers and equipment before anything leaves.
- **Question:** "When a truck shows up for a pickup at your facilities, how does your team confirm the driver and equipment [role ending from `roles.md`]?"
- **Solution:** It verifies the driver, truck, and trailer against the planned pickup. If anything doesn't match, the truck is held at the gate before the load leaves.
- **Best proof:** Werner (its VP of Terminal Management says it keeps their equipment more secure). For retail, Skechers.
- **Offer:** "Want me to send you a sample gate record from a pickup?"
- **Subject:** Fraudulent pickups at [Company] facilities

### S2. Prove who took it

- **What the ad said:** Nothing leaves without authorization. If it doesn't match, it doesn't move. Timestamped photos and video support audits, claims, and investigations.
- **Question:** "If a load leaves your facilities with the wrong driver, how would your team prove who took it?"
- **Solution:** It records timestamped photos and video of every driver, truck, and trailer at the gate. The team can search the record by date, plate, trailer, or driver and export it for a claim.
- **Best proof:** United States Cold Storage (captures DOT and container numbers on every arriving truck), or Werner if it wasn't used in Email 1.
- **Offer:** "Want to see a quick video of it in action?"
- **Subject:** Photo records of every truck at [Company] facilities

### S3. The same checks on every shift

- **What the ad said:** Verify every asset and driver around the clock. Outpost checks the truck, trailer, driver, and seal against the system of record and confirms the move.
- **Question:** "How do you make sure every gate guard runs the same checks on every shift?"
- **Solution:** It follows the customer's facility SOPs on every truck checking in 24/7. It reads equipment IDs, makes sure trucks are hauling the right trailers, and confirms seals are present. If something doesn't match, the team gets an alert before the truck moves.
- **Best proof:** the customer list sentence.
- **Offer:** "Want to see a quick video of everything it logs at the gate?"
- **Subject:** Gate guards at [Company] facilities

---

## Operations angles

### O1. Gate staffing cost

- **What the ad said:** Cut gate operating costs. No capital expense.
- **Question:** "What does it cost each month to staff your facility gates?"
- **Solution:** It automates the check-in process, so the team handles only the exceptions. There's no upfront equipment cost and billing starts once it's live and accepted. Keep both commercial points: no upfront equipment cost means no capital expense, and billing once it's live and accepted means no cost until it works.
- **Best proof:** the customer list sentence. Never pair Werner with a savings claim.
- **Offer:** "Would a cost comparison for one of your facilities be useful?"
- **Subject:** Gate staffing costs at [Company] facilities

### O2. Wrong trailer pulls

- **What the ad said:** Stop misdispatches before they move. Every move is matched to the TMS or YMS, with holds and red tags enforced at the gate.
- **Question:** "When a driver leaves your facility with a trailer, who confirms it's the right one before it's gone?" Use "who confirms," never "what confirms."
- **Solution:** It matches every driver, tractor, and trailer to the planned move in their TMS or YMS. If the trailer is wrong or on hold, the gate stays closed and the team gets an alert.
- **Best proof:** Werner (its VP of Terminal Management says it gives them cleaner data).
- **Offer:** "Would a few screenshots of that check be useful?"
- **Subject:** Stopping wrong trailer pulls at [Company] facilities

### O3. Gate wait time

- **What the ad said:** Keep trucks turning around the clock. Drivers check in from the cab in their own language and get dock directions.
- **Question:** "How often do trucks stack up at your facility gates?"
- **Solution:** Drivers check in from the cab in seconds, in their own language, with no app to download. The team steps in only when a driver needs extra help. Dock directions are possible only when it's connected to their TMS, YMS, WMS, or other system; say so if you mention them.
- **Best proof:** United States Cold Storage (faster throughput and fewer manual interventions at the gate).
- **Offer:** "Want to see a quick video of a driver checking in?"
- **Subject:** Gate dwell at [Company] facilities

### O4. Gate coverage

- **What the ad said:** Gate coverage that never calls out. Remote operators back up the gate around the clock.
- **Question:** "When a gate guard calls out, how does your team cover the gate?"
- **Solution:** It runs the same check-in process on every shift. The customer's team or Outpost's remote operators step in 24/7 when a driver needs extra help.
- **Best proof:** United States Cold Storage (keeps its gate running reliably without adding headcount).
- **Offer:** "Want to see a quick video of a remote operator handling an exception?"
- **Subject:** Gate coverage at [Company] facilities

### O5. Yard records

- **What the ad said:** Always know what's on your yard. Every move at the gate updates your system.
- **Question:** "How accurate are the trailer records that come from your gate today?"
- **Solution:** It records every entry and exit with photos and a timestamp, and sends each move to their TMS, YMS, WMS, or other system with no manual data entry.
- **Best proof:** Werner (its VP of Terminal Management says it gives them cleaner data and faster terminal throughput). For cold chain, grocery, CPG, and 3PLs, United States Cold Storage (its Area General Manager says it gives his team real-time visibility into gate activity).
- **Offer:** "Want me to send you a sample gate record?"
- **Subject:** Yard records at [Company] facilities

## Figures from the ads that emails leave out

The 35% rise in deceptive pickups and $725M in cargo theft appear in the ads but aren't in `proof-library.md`, so emails don't use them.
