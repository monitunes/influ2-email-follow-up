# Roles

This file maps job titles to the ending of the Security opening question, and lists the titles to skip.

## Security persona: how the S1 question ends

S1's question ends with what's at stake for the contact's role. Match the job title to the closest row. S2 and S3 use their questions as written in `ad-angles.md`.

| Role | Typical titles | S1 question ends with |
|---|---|---|
| Asset protection or loss prevention leader | Director or VP of Asset Protection, Loss Prevention, AP/LP Manager, Regional AP Manager | "...before the load is gone?" or "...before it turns into a claim?" |
| Site or plant security | Security Manager, Site Security Lead, Plant Security, Facility Security | "...before the trailer leaves the yard?" |
| Corporate security or risk | Director of Corporate Security, Global Security, Supply Chain Security, Risk Manager, Investigations | "...before the load is gone?" |
| Facilities or plant manager | Facilities Manager, Plant Manager, Site Manager, Director of Facilities | "...before it leaves?" |
| Fleet or LTL security | Fleet Security, Terminal Security, Cargo Security at a carrier | "...before it hits the road?" |

If a title fits more than one row, use the narrower one. If none fits but the title is plainly a security or asset protection buyer, use the asset protection row.

## Operations persona

Operations questions are used as written in `ad-angles.md`. Where the question says "your facility," it can name the facility type that fits the contact's role, but only when the title states it:

| Role | Typical titles | Facility word |
|---|---|---|
| Warehouse or DC operations | DC Manager, Warehouse Manager, Director of Distribution Operations | DC or warehouse |
| Yard or terminal operations | Yard Manager, Terminal Manager, Gate Supervisor | terminal |
| Site or plant operations | Plant Manager, Site Operations Manager | plant |
| Everyone else | | facility |

## Skip list

Don't draft for these titles. Flag them for review in the Slack thread instead (SKILL.md run step 4). They clicked the ad, but they rarely own the gate.

- Commodity risk, financial risk, or credit risk
- IT security, network security, cybersecurity, or information security
- HR systems, HRIS, Workday, or payroll
- Sales, business development, account management, or partnerships
- Marketing or communications
- Security product or solutions roles at companies that sell security (usually selling security products to others)

When a title is ambiguous, such as "Market Loss Prevention Manager" at a retailer (often store-focused), draft the emails and add "Title may be store-focused; worth a look" to the ✅ thread reply.
