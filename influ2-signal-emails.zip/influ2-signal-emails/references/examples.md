# Example

One full sequence that passes every rule in `drafting-rules.md`. It shows the structure, length, and tone. Each contact gets fresh copy built from the angle, role, and segment.

Each email is shown as it reads in the inbox, with the HubSpot greeting and signature in brackets, followed by the HTML the skill writes to the body property.

---

**Contact:** Patrick, Manager, Risk, Hormel
**Company:** OGA Segment Shipper, Subsegment CPG / Food & Bev. Gate Owner: Greg Mason.
**Clicked:** oga - ai.2 security - deceptive pickup → S1, S2, S3
**Role:** corporate security or risk → S1 ends "...before the load is gone?"

### Email 1 (S1)

**Subject:** Fraudulent pickups at Hormel facilities

> [Patrick,]
>
> When a truck shows up for a pickup at your facilities, how does your team confirm the driver and equipment before the load is gone?
>
> I'm Greg from Outpost. We automate the gate check-in process, verifying the driver, truck, and trailer against the planned pickup. If anything doesn't match, the truck is held at the gate before the load leaves. Werner's VP of Terminal Management says it keeps their equipment more secure.
>
> Want me to send you a sample gate record from a pickup?
>
> [Signature]

```html
<p>When a truck shows up for a pickup at your facilities, how does your team confirm the driver and equipment before the load is gone?</p>
<p>I'm Greg from <a href="https://outpost.us/gate-automation-for-security/">Outpost</a>. We automate the gate check-in process, verifying the driver, truck, and trailer against the planned pickup. If anything doesn't match, the truck is held at the gate before the load leaves. Werner's VP of Terminal Management says it keeps their equipment more secure.</p>
<p>Want me to send you a sample gate record from a pickup?</p>
```

### Email 2 (S2)

**Subject:** Photo records of every truck at Hormel facilities

> [Patrick,]
>
> If a load leaves your facilities with the wrong driver, how would your team prove who took it?
>
> Outpost Gate Automation records timestamped photos and video of every driver, truck, and trailer at the gate. Your team can search the record by date, plate, trailer, or driver and export it for a claim. United States Cold Storage uses it to capture DOT and container numbers on every arriving truck.
>
> Want to see a quick video of it in action?
>
> [Signature]

```html
<p>If a load leaves your facilities with the wrong driver, how would your team prove who took it?</p>
<p><a href="https://outpost.us/gate-automation-for-security/">Outpost Gate Automation</a> records timestamped photos and video of every driver, truck, and trailer at the gate. Your team can search the record by date, plate, trailer, or driver and export it for a claim. United States Cold Storage uses it to capture DOT and container numbers on every arriving truck.</p>
<p>Want to see a quick video of it in action?</p>
```

### Email 3 (S3)

**Subject:** Gate guards at Hormel facilities

> [Patrick,]
>
> How do you make sure every gate guard runs the same checks on every shift?
>
> Outpost Gate Automation follows your facility SOPs on every truck checking in 24/7. It reads equipment IDs, makes sure trucks are hauling the right trailers, and confirms seals are present. If something doesn't match, your team gets an alert before the truck moves.
>
> Carriers like Werner, retailers like Skechers, and cold storage providers like United States Cold Storage chose Outpost for their gates.
>
> Want to see a quick video of everything it logs at the gate?
>
> [Signature]

```html
<p>How do you make sure every gate guard runs the same checks on every shift?</p>
<p><a href="https://outpost.us/gate-automation-for-security/">Outpost Gate Automation</a> follows your facility SOPs on every truck checking in 24/7. It reads equipment IDs, makes sure trucks are hauling the right trailers, and confirms seals are present. If something doesn't match, your team gets an alert before the truck moves.</p>
<p>Carriers like Werner, retailers like Skechers, and cold storage providers like United States Cold Storage chose Outpost for their gates.</p>
<p>Want to see a quick video of everything it logs at the gate?</p>
```
