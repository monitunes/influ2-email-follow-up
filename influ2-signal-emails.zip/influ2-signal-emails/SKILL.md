---
name: influ2-signal-emails
description: Turns Influ2 buyer-intent signals from the #influ2-signals Slack channel into drafted outreach emails on the contact's HubSpot record, for a specific sales rep. Has two modes. SETUP mode walks a new user through configuration in chat (connector check, who to scan for, email voice samples, cloning the HubSpot sequence, a dry run, then creating the recurring scheduled task). RUN mode is the every-4-hours job. Use this skill whenever someone asks to set up, install, configure, or start the Influ2 signal emails, or says "check for new signals", "run the signal emails", "process influ2-signals", or when a scheduled task fires with an INFLU2-SIGNAL-CONFIG block in its prompt.
---

# Influ2 Signal → Email → HubSpot

Watches `#influ2-signals` for Influ2 buyer-intent notifications that tag the user, drafts a short outreach email for each contact, and writes the subject and body onto that contact's HubSpot record. The user's HubSpot sequence then pulls those two properties into its first step. Nothing is ever sent by this skill.

## Which mode am I in?

Check the prompt that started this session:

- It contains a block that begins with `INFLU2-SIGNAL-CONFIG` → **RUN mode**. Jump to "Run mode" below.
- The user is asking to set up, install, configure, or get started → **SETUP mode**.
- The user asks to "check for new signals" or similar but there is no config block → they haven't finished setup, or they're testing manually. Ask whether they'd like to run setup first. If they say they already set it up, ask them to paste the config block from their scheduled task, then proceed in RUN mode.

## Constants (same for every user at Outpost)

- Slack channel: `#influ2-signals` = `C0B5TA40V2B`
- Influ2 workspace ID: `04f34b0f-5a66-4614-8bc2-47e538421f30`
- HubSpot portal ID: `22778013`
- HubSpot contact properties written: `influ2_email_1_subject`, `influ2_email_1_body`
- Master HubSpot sequence to clone: https://app.hubspot.com/sequences/22778013/sequence/311074822/edit
- Monica Thorne's Slack user ID (gets notified when someone finishes setup): `U090B9GEF5F`
- Run cadence: every 4 hours, 24-hour lookback. First manual sweep uses a 7-day lookback.

---

# SETUP mode

Setup is a conversation. Ask one question at a time, wait for the answer, then move on. Don't dump the whole list up front. Keep each message short; the user is a sales rep, not an admin.

Open with one or two sentences on what this does (drafts follow-up emails from Influ2 signals into HubSpot for them to review and send; never sends anything) and that setup takes about ten minutes.

## Setup step 1 — Connector check

Before asking anything, quietly confirm the three connectors work by making one light call each:

- Slack: `slack_search_users` with the user's own name or email
- HubSpot: `get_user_details` with `TOOL_INFORMATION`, and confirm `CONTACT.write` is `AVAILABLE`
- Influ2: `influ2_get_workspace_info`

If any call fails or the tool isn't available, stop and tell the user exactly which connector is missing and how to fix it: Settings → Connectors in Claude, find the connector, click Connect, sign in, then come back and say "continue setup." If HubSpot connects but `CONTACT.write` isn't available, tell them their HubSpot user needs contact edit permission and to ask Monica.

If all three work, say so in one line and move on. Don't list what you checked.

## Setup step 2 — Who to scan for

From the Slack lookup in step 1, you should already have the user's Slack user ID. Confirm it: "I'll watch for Influ2 signals that tag you (@Their Name). Right?"

Then ask: "Is anyone else on the team also running this skill on the same channel?" 

- If no: `EXCLUDE_SLACK_IDS` is empty.
- If yes: ask for the name(s), look up their Slack user ID(s), and ask: "When a signal tags both of you, who should draft the email, you or them?" If the answer is "them," add their ID(s) to `EXCLUDE_SLACK_IDS` (messages tagging those people get skipped). If the answer is "me," leave the list empty and tell the user the other person needs to add *them* to their own exclusion list, otherwise both of you will draft for the same contact.

## Setup step 3 — Email voice samples

Ask the user to paste 3 to 5 emails they've actually sent to prospects. Prospecting or follow-up emails are best. They can paste them one at a time or all at once.

Once you have them, write a **voice profile** of 6 to 10 short lines that captures how this person writes. Cover: typical sentence length, whether they use contractions, how they open (question, observation, statement), how they close, vocabulary they lean on, anything they never do. Be concrete ("opens with a one-line observation about the prospect's operation, never a question" beats "direct style").

Show the profile and ask: "Does this sound like you? Anything to change?" Revise until they say yes. This profile becomes `VOICE_PROFILE` in the config.

Note for drafting: the profile shapes tone and rhythm. The hard rules in "Drafting rules" below (no salutation, no sign-off, under 100 words, one question, never reference the signal) always win. If a sample email has a greeting and signature, that's fine; the HubSpot sequence template adds those.

## Setup step 4 — Clone the HubSpot sequence

Tell the user:

> One step in HubSpot. Open this sequence: https://app.hubspot.com/sequences/22778013/sequence/311074822/edit
>
> Click **Actions → Clone** (top right). Name the copy "[Your name] - Influ2 Signal". 
>
> Leave step 1 alone. It pulls the drafted email from the contact record. Edit any of the later steps however you want.
>
> When you're done, paste me the link to your new sequence.

Wait for the link. Don't try to verify it in HubSpot; just confirm it looks like a HubSpot sequence URL. Store it as `SEQUENCE_URL`.

Then send Monica a Slack DM via `slack_send_message` to user `U090B9GEF5F`:

> [User's full name] set up Influ2 Signal Emails. New sequence: [SEQUENCE_URL]

Tell the user you've let Monica know.

## Setup step 5 — Dry run

Say: "Let me draft a couple of test emails so you can check the voice before this runs on its own."

Run "Run mode" steps 1 through 4 with a 7-day lookback, but:

- Stop after drafting **two** emails (pick the two most recent qualifying signals). If there are fewer than two qualifying signals in the last 7 days, use what's there; if there are none, say so and skip to step 6.
- Do **not** write to HubSpot and do **not** post any Slack thread replies.
- Show the user each draft with the contact's name, title, and company above it.

Ask: "How do these read? Anything you'd change?" If they give feedback, update `VOICE_PROFILE` and redraft. Repeat until they're happy.

## Setup step 6 — Create the scheduled task

Build the config block:

```
INFLU2-SIGNAL-CONFIG
USER_NAME: <full name>
USER_SLACK_ID: <Uxxxxxxxx>
EXCLUDE_SLACK_IDS: <comma-separated IDs, or "none">
SEQUENCE_URL: <url>
VOICE_PROFILE:
<the agreed voice profile, one item per line>
END-CONFIG
```

Create a **scheduled task** (recurring, every 4 hours, cron `0 */4 * * *`) named "Influ2 Signal Emails - [User first name]". Its prompt must be self-contained since each run starts a fresh session:

> Run the influ2-signal-emails skill in RUN mode with a 24-hour lookback. Config follows.
>
> [the full config block]

Tell the user it's set up, that it will check every 4 hours, and that they can pause or change it anytime by asking Claude ("pause my Influ2 signal task" / "update my Influ2 voice profile").

## Setup step 7 — Offer the first sweep

Ask: "Want me to run the first full sweep now? It'll go back 7 days and write drafts to HubSpot for everything it finds."

If yes, run RUN mode with a 7-day lookback using the config you just built, including HubSpot writes and Slack thread markers. If no, you're done; the scheduled task picks up from the next 24-hour window.

---

# RUN mode

Read the config block. `USER_SLACK_ID`, `EXCLUDE_SLACK_IDS`, `VOICE_PROFILE`, and `USER_NAME` drive everything below. Lookback is 24 hours unless the prompt says otherwise.

## Run step 1 — Pull candidate messages

Call `slack_read_channel` on `C0B5TA40V2B` with `oldest` set to the lookback window and `response_format: detailed` (thread info is needed for step 2).

Keep only messages that:
- Come from the Influ2 bot ("New Engagement Intent" messages)
- Tag `<@USER_SLACK_ID>`
- Do **not** tag any ID in `EXCLUDE_SLACK_IDS`

Discard everything else.

From each qualifying message, extract:
- **target_id**: the 32-char hex ID in the `/target/<id>` URL (the Influ2 contact ID)
- **account_id**: the hex ID in the `/account/<id>` URL
- **contact name, title, company name**
- **what happened** (e.g. "Clicked on ad and visited landing page") and **the stated interest** (e.g. "interested in enhancing asset protection with AI security solutions")
- Any buying-group context line, for internal triage only; never mentioned in the drafted email
- The message's `channel_id` and `ts` (needed for steps 2 and 5)

## Run step 2 — Skip already-processed messages

There's no reaction-add tool, so a thread reply is the processed marker. Before drafting anything for a message, check its thread (`slack_read_thread`, or the reply count and preview from step 1). Skip it if any reply starts with "✅ Drafted". This is what keeps the 4-hour runs from re-processing the same signal.

## Run step 3 — Find the HubSpot contact

Try in this order, stop at the first success:

1. **Influ2 lookup (preferred).** Call `influ2_get_audience` with `filters.contact.ids: [target_id]`, `include_level: full`, and the workspace ID above. If the user's Influ2 access is owner-scoped and the contact isn't assigned to them, this will 404. That's expected, not an error; move on. On success, pull the contact's `email`, then call `search_crm_objects` on `CONTACT` filtering `email EQ <email>`.
2. **Name + company fallback.** Call `search_crm_objects` on `CONTACT` with `query` set to the contact's full name, then confirm the associated company name matches (or look the company up by name via `search_crm_objects` on `COMPANY` and use an `associatedWith` filter).
3. **No match.** Don't guess. Post a thread reply: "⚠️ Couldn't find a matching HubSpot contact for <name> at <company>. Skipping." and move on.

## Run step 4 — Draft the email

Draft an outreach email built around the **topic** the signal surfaced, in the user's voice per `VOICE_PROFILE`.

### The one rule that can't be broken

Never reference the ad, the landing page, the click, the visit, or that anyone is watching their activity. No "saw you looked into," "noticed your interest," "came across your visit," or anything that implies tracking. The interest area only picks the topic. The email should read like the user independently decided this was worth a note to this person given their role, not like a triggered response to their behavior. If a draft would tip off that it's signal-triggered, rewrite it.

### Drafting rules

- **No salutation, no sign-off, no signature.** Body text only. The HubSpot sequence template adds those.
- Plain text. No bullet points, no images, no more than one hyperlink.
- Open with the pain or problem tied to the interest area and their role or company, stated as an observation about their world, not about their behavior on a website.
- **Match vocabulary to the persona.** The opener has to sound like it was written for that specific title:
  - Security / Asset Protection / Loss Prevention titles: "gate," "security," "verification," "deceptive pickup," "audit trail" are their native vocabulary
  - Ops / Warehouse / Transportation / Logistics titles: don't lead with "gate" or "security." Reframe as carrier check-in, yard entry, dock and turn times, throughput, driver wait time, manual staffing cost
  - Real Estate / Strategy / Corporate titles: reframe around facility footprint, capex, or network efficiency rather than the gate itself
  - If a title doesn't fit any of these, default to the specific interest phrase from the Slack message rather than guessing a persona
- One tight paragraph connecting that pain to what Outpost does, concrete, in the persona's vocabulary.
- End with exactly one specific, easy-to-answer question. Never two.
- Under 100 words.
- Contractions are fine. No em dashes, en dashes, or double hyphens; use semicolons or restructure.
- Apply `VOICE_PROFILE` for rhythm, openers, and word choice. Where the profile and these rules conflict, these rules win.
- Subject line: under 40 characters, specific to the topic, no rhetorical fluff, no merge tokens, no reference to a "signal" or "visit."

### Two examples of the persona shift on the same product

Security/AP persona. "Priya Donohue, Regional Manager, Asset Protection at Ralph Lauren," interest: "enhancing asset protection with AI security solutions":

> **Subject:** Asset protection at the gate
>
> Most asset protection programs are airtight everywhere except the gate; drivers and trailers get waved through on trust while the rest of the facility runs on verification. Outpost closes that gap by checking every driver and trailer against the load before the gate opens, so a mismatch gets caught before it happens instead of after a loss.
>
> Is gate-level verification part of your asset protection strategy today, or still a gap?

Ops/Warehouse persona. "Rommel Atanacio, Manager, Warehouse at Stitch Fix," interest: "automating gate operations to reduce costs":

> **Subject:** Manual costs at carrier check-in
>
> Carrier check-in is one of the last fully manual steps in most yards; a guard verifying paperwork by hand while trucks queue behind. Outpost automates that step entirely, verifying drivers and trailers and routing them in without staffing the booth, so check-in stops being the bottleneck it usually is.
>
> How much of your current staffing cost is tied up in manual check-in versus the actual yard work?

## Run step 5 — Check permissions, then write to HubSpot

Before the first write of a run, call `get_user_details` with `TOOL_INFORMATION` and confirm `CONTACT.write` is `AVAILABLE`. If it isn't, stop and tell the user plainly which permission is missing. Don't fail silently.

For each matched contact, call `manage_crm_objects` with an `updateRequest` setting:
- `influ2_email_1_subject` → the drafted subject
- `influ2_email_1_body` → the drafted body

Follow the tool's confirmation flow the first time in a session; after that, batch the rest without re-confirming each one unless something looks off.

## Run step 6 — Mark it processed and report back

Reply in the Slack message's thread:

> ✅ Drafted → written to [Contact Name's HubSpot record](https://app.hubspot.com/contacts/22778013/record/0-1/<contactId>)

This closes the loop for anyone watching the channel and is the marker step 2 checks next run.

At the end of the run, give the user a one-line summary: signals found, drafted, skipped (already processed), and needing attention (no HubSpot match).

## Notes

- Never send the email. This skill drafts and stores; the user reviews and sends through their sequence.
- If Influ2 returns richer history for a contact (multiple engagements, buying-group context), let it inform topic choice, but none of it belongs in the email.
- If the user asks to change their voice profile or exclusion list later, update the config block and ask them to update the scheduled task's prompt with the new block (or offer to recreate the task).
