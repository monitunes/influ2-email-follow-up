---
name: influ2-signal-emails
description: Turns Outpost Gate Automation (OGA) Influ2 ad clicks from the #influ2-signals Slack channel into a three-email follow-up sequence written onto the contact's HubSpot record, for a specific sales rep. Has two modes. SETUP mode walks a new rep through configuration in chat (connector check, who to scan for, copying the HubSpot sequence, a dry run, then creating the recurring scheduled task). RUN mode is the every-4-hours job. Use this skill whenever someone asks to set up, install, configure, or start the Influ2 signal emails, or says "check for new signals", "run the signal emails", "process influ2-signals", or when a scheduled task fires with an INFLU2-SIGNAL-CONFIG block in its prompt.
---

# Influ2 Signal → Three Emails → HubSpot

Watches `#influ2-signals` for Influ2 "New Engagement Intent" notifications that tag the rep. For each contact who clicked an Outpost Gate Automation (OGA) ad, it writes three follow-up emails from Outpost's rules and writes their subjects and bodies onto the contact's HubSpot record. Writing `influ2_email_1_subject` triggers a HubSpot workflow that enrolls the contact in the rep's sequence, which sends the three emails from the properties. This skill never sends or enrolls anything itself.

The copy is written fresh for each contact. Nothing here is a fill-in-the-blank template. The reference files say what each email has to accomplish and what it's allowed to claim; the skill writes the sentences.

## Reference files

Read all five before drafting anything. They are short.

- `references/ad-angles.md`: which ad the contact clicked, which angle each of the three emails takes, and each angle's question, solution, proof, offer, and subject
- `references/drafting-rules.md`: structure, writing rules, HTML format, and the check every draft has to pass
- `references/roles.md`: how the Security question ends for each role, and which titles to skip
- `references/proof-library.md`: the only customer proof the emails may use, and which proof fits which segment
- `references/examples.md`: a full three-email sequence that passes every rule

## Which mode am I in?

Check the prompt that started this session:

- It contains a block that begins with `INFLU2-SIGNAL-CONFIG` → **RUN mode**. Jump to "RUN mode" below.
- The user is asking to set up, install, configure, or get started → **SETUP mode**.
- The user asks to "check for new signals" or similar but there is no config block → they haven't finished setup, or they're testing manually. Ask whether they'd like to run setup first. If they say they already set it up, ask them to paste the config block from their scheduled task, then proceed in RUN mode.

## Constants (same for every rep at Outpost)

- Slack channel: `#influ2-signals` = `C0B5TA40V2B`
- Influ2 workspace ID: `04f34b0f-5a66-4614-8bc2-47e538421f30`
- Influ2 OGA programs: Security = `20402660-8efb-4a3b-9377-c976cde93d82`, Operations = `29f29f60-8cf3-4992-b7ef-44ae1fa13790`
- HubSpot portal ID: `22778013`
- HubSpot contact properties written (all six in one update):
  - `influ2_email_1_subject`, `influ2_email_1_body`
  - `influ2_email_2_subject`, `influ2_email_2_body`
  - `influ2_email_3_subject`, `influ2_email_3_body`
  - Subjects are plain text. Bodies are rich text and take HTML (see `drafting-rules.md`).
- HubSpot properties read:
  - Contact: `firstname`, `jobtitle`, `last_clicked_creative_name`, `influ2_program`, `oga_persona`, `hs_sequences_is_enrolled`, `hs_latest_sequence_enrolled`, `currently_in_sequence_enrollment_workflow`, `influ2_email_1_subject`
  - Associated company: `company_name_friendly`, `name`, `gatekeeper_owner` (label "Gate Owner"), `gatekeeper_segment___industry` (OGA Segment), `gatekeeper_segment___tier` (OGA Subsegment)
- "Do Not Send" sequence IDs (enrollment in these doesn't count as being in a sequence): `306365234`
- Landing pages: Security = `https://outpost.us/gate-automation-for-security/`, Operations = `https://outpost.us/gate-automation-for-operations/`
- Master HubSpot sequence to copy: https://app.hubspot.com/sequences/22778013/sequence/311074822/edit
- Monica Thorne's Slack user ID (gets notified when someone finishes setup): `U090B9GEF5F`
- Run cadence: every 4 hours, 24-hour lookback. First manual sweep uses a 7-day lookback.

---

# SETUP mode

Setup is a conversation. Ask one question at a time, wait for the answer, then move on. Don't dump the whole list up front. Keep each message short; the user is a sales rep, not an admin.

Open with one or two sentences on what this does: when someone at one of their accounts clicks an Outpost Gate Automation ad, Claude writes a three-email follow-up onto the contact in HubSpot, and HubSpot enrolls the contact in their sequence automatically. Setup takes about ten minutes.

## Setup step 1 — Connector check

Before asking anything, quietly confirm the three connectors work by making one light call each:

- Slack: `slack_search_users` with the user's own name or email
- HubSpot: `discover_hubspot_schema` with `GET_OBJECT_TYPES` for `CONTACT`, and confirm `writeAccess` is `AVAILABLE`
- Influ2: `influ2_get_workspace_info`

If any call fails or the tool isn't available, stop and tell the user exactly which connector is missing and how to fix it: Settings → Connectors in Claude, find the connector, click Connect, sign in, then come back and say "continue setup." If HubSpot connects but contact write access isn't available, tell them their HubSpot user needs contact edit permission and to ask Monica.

If all three work, say so in one line and move on. Don't list what you checked.

## Setup step 2 — Who to scan for

From the Slack lookup in step 1, you should already have the user's Slack user ID. Confirm it: "I'll watch for Influ2 signals that tag you (@Their Name). Right?"

Influ2 tags the Gate Owner of the contact's company, so the rep should be the Gate Owner on the accounts they want covered. If they aren't sure, tell them to check the "Gate Owner" field on a few of their companies in HubSpot.

Then ask: "Is anyone else on the team also running this skill on the same channel?"

- If no: `EXCLUDE_SLACK_IDS` is empty.
- If yes: ask for the name(s), look up their Slack user ID(s), and ask: "When a signal tags both of you, who should draft the emails, you or them?" If the answer is "them," add their ID(s) to `EXCLUDE_SLACK_IDS` (messages tagging those people get skipped). If the answer is "me," leave the list empty and tell the user the other person needs to add *them* to their own exclusion list, otherwise both of you will draft for the same contact.

## Setup step 3 — Copy the HubSpot sequence

Tell the user:

> One step in HubSpot. Open this sequence: https://app.hubspot.com/sequences/22778013/sequence/311074822/edit
>
> Click **Actions → Clone** (top right). Name the copy "[Your name] - Influ2 Signal".
>
> Leave all three email steps as they are. Each one pulls its subject and body from the contact record, and HubSpot adds the greeting and your signature.
>
> When you're done, paste me the link to your new sequence.

Wait for the link. Don't try to verify it in HubSpot; just confirm it looks like a HubSpot sequence URL. Store it as `SEQUENCE_URL`.

Then send Monica a Slack DM via `slack_send_message` to user `U090B9GEF5F`:

> [User's full name] set up Influ2 Signal Emails. New sequence: [SEQUENCE_URL]

Tell the user you've let Monica know, and that she connects the sequence to the enrollment workflow.

## Setup step 4 — Dry run

Say: "Let me draft a test sequence so you can see what these look like before this runs on its own."

Run RUN mode steps 1 through 5 with a 7-day lookback, but:

- Stop after drafting for **two** contacts (pick the two most recent qualifying signals). If there are fewer than two in the last 7 days, use what's there; if there are none, say so and skip to step 5.
- Do **not** write to HubSpot and do **not** post any Slack thread replies. Writing to HubSpot would enroll the contact.
- Show the user each contact's name, title, company, the ad they clicked, and all three emails as they'll read (subject, then body as plain paragraphs).

Ask: "How do these read? Anything that's wrong about your accounts or how you'd describe Outpost?" If they flag a factual problem, fix it in the draft and tell them you'll pass it to Monica so the rules get updated for everyone. Don't create per-rep writing rules; the rules are shared.

## Setup step 5 — Create the scheduled task

Build the config block:

```
INFLU2-SIGNAL-CONFIG
USER_NAME: <full name>
USER_SLACK_ID: <Uxxxxxxxx>
EXCLUDE_SLACK_IDS: <comma-separated IDs, or "none">
SEQUENCE_URL: <url>
END-CONFIG
```

Create a **scheduled task** (recurring, every 4 hours, cron `0 */4 * * *`) named "Influ2 Signal Emails - [User first name]". Its prompt must be self-contained since each run starts a fresh session:

> Run the influ2-signal-emails skill in RUN mode with a 24-hour lookback. Config follows.
>
> [the full config block]

Tell the user it's set up, that it will check every 4 hours, and that they can pause or change it anytime by asking Claude ("pause my Influ2 signal task").

## Setup step 6 — Offer the first sweep

Ask: "Want me to run the first full sweep now? It goes back 7 days, writes the emails to HubSpot, and HubSpot will enroll those contacts in your sequence."

If yes, run RUN mode with a 7-day lookback using the config you just built, including HubSpot writes and Slack thread markers. If no, you're done; the scheduled task picks up from the next 24-hour window.

---

# RUN mode

Read the config block. `USER_SLACK_ID`, `EXCLUDE_SLACK_IDS`, and `USER_NAME` drive everything below. Config blocks from the previous version of this skill may include a `VOICE_PROFILE` section; ignore it. Lookback is 24 hours unless the prompt says otherwise. Read the five reference files before step 5.

## Run step 1 — Pull candidate messages

Call `slack_read_channel` on `C0B5TA40V2B` with `oldest` set to the lookback window and `response_format: detailed` (thread info is needed for step 2).

Keep only messages that:
- Come from the Influ2 bot ("New Engagement Intent" messages)
- Tag `<@USER_SLACK_ID>`
- Do **not** tag any ID in `EXCLUDE_SLACK_IDS`

Discard everything else.

From each qualifying message, extract:
- **target_id**: the 32-char hex ID in the `/target/<id>` URL (the Influ2 contact ID)
- **account_id**: the hex ID in the `/account/<id>` URL
- **contact name, title, company name**
- **what happened** (e.g. "Clicked on ad and visited landing page") and **the stated interest**
- Any buying-group context line, for internal triage only; never mentioned in an email
- The message's `channel_id` and `ts` (needed for steps 2 and 7)

## Run step 2 — Skip already-processed messages

A thread reply is the processed marker. Before doing anything for a message, check its thread (`slack_read_thread`, or the reply count and preview from step 1). Skip it if any reply starts with "✅ Drafted", "⏸️", or "⚠️". This keeps the 4-hour runs from re-processing the same signal.

## Run step 3 — Find the HubSpot contact and company

Try in this order, stop at the first success:

1. **Influ2 lookup (preferred).** Call `influ2_get_audience` with `filters.contact.ids: [target_id]`, `include_level: full`, and the workspace ID above. If the user's Influ2 access is owner-scoped and the contact isn't assigned to them, this will 404. That's expected, not an error; move on. On success, keep the contact's `email`, program, and any engagement detail that names the ad, then call `search_crm_objects` on `CONTACT` filtering `email EQ <email>`.
2. **Name + company fallback.** Call `search_crm_objects` on `CONTACT` with `query` set to the contact's full name, then confirm the associated company name matches (or look the company up by name via `search_crm_objects` on `COMPANY` and use an `associatedWith` filter).
3. **No match.** Don't guess. Post a thread reply: "⚠️ Couldn't find a matching HubSpot contact for <name> at <company>. Skipping." and move on.

Fetch the contact properties and the associated company properties listed under Constants.

## Run step 4 — Decide whether to draft

Check these in order. The first one that applies decides; post the thread reply shown and move to the next message.

1. **Already drafted.** `influ2_email_1_subject` already has a value → "⏸️ Already has Influ2 emails on the record. Not redrafted." Never overwrite existing drafts; the contact may already be mid-sequence.
2. **Already in a sequence.** `hs_sequences_is_enrolled` is true and `hs_latest_sequence_enrolled` is **not** in the Do Not Send list, or `currently_in_sequence_enrollment_workflow` is Yes → "⏸️ <name> is already in a sequence. Not drafted." Enrollment in a Do Not Send sequence doesn't count; keep going.
3. **Not an OGA signal.** No OGA ad and no OGA program (see `ad-angles.md`, "Pick the persona and angle") → "⏸️ Not an Outpost Gate Automation signal. Skipped."
4. **Title on the skip list.** The job title matches the skip list in `roles.md` → "⚠️ <name> (<title>) doesn't look like a gate buyer. Not drafted; flagging for review."
5. **No Gate Owner.** The company's `gatekeeper_owner` is empty, or `search_owners` shows that owner as inactive → "⚠️ <company> has no active Gate Owner, so there's no sender for the sequence. Not drafted." The workflow sends as the Gate Owner, so the email can't introduce anyone else.

Otherwise, draft.

## Run step 5 — Draft the three emails

Collect the inputs:

- **First name**: not needed. The sequence adds "{First Name}," with "Hello" as the default.
- **Gate Owner first name**: look up `gatekeeper_owner` with `search_owners` (ownerIds) and take the first name. It goes in Email 1's intro.
- **Company name for subjects**: `company_name_friendly`. If it's empty, use `name` with legal suffixes removed (Inc., LLC, Corp., Co., Ltd., L.P., and the like) and normal capitalization, so "DALE AND DARRYL LOGISTICS LLC" becomes "Dale and Darryl Logistics". If there's no company name at all, use "your gate".
- **Persona, clicked ad, and the three angles**: from `ad-angles.md`.
- **Role and the question ending that fits it**: from `roles.md`.
- **Segment and proof**: OGA Segment and Subsegment from the company, then `proof-library.md`.

Write Email 1, Email 2, and Email 3 following `drafting-rules.md`, using the angle assigned to each in `ad-angles.md`. Run the check in `drafting-rules.md` on every email. Fix and recheck anything that fails. Don't move on until all three pass.

## Run step 6 — Write to HubSpot

Before the first write of a run, confirm contact `writeAccess` is `AVAILABLE` (`discover_hubspot_schema`, `GET_OBJECT_TYPES`, `CONTACT`). If it isn't, stop and tell the user plainly which permission is missing. Don't fail silently.

For each contact, make **one** `manage_crm_objects` call with an `updateRequest` that sets all six properties together. The workflow enrolls the contact as soon as `influ2_email_1_subject` has a value, so Emails 2 and 3 must already be on the record at that moment. Never write the subjects and bodies in separate calls.

Follow the tool's confirmation flow the first time in a session; after that, batch the rest without re-confirming each one unless something looks off.

## Run step 7 — Mark it processed and report back

Reply in the Slack message's thread:

> ✅ Drafted 3 emails (<Persona>: <angle used for Email 1>) → [<Contact Name>'s HubSpot record](https://app.hubspot.com/contacts/22778013/record/0-1/<contactId>)

This closes the loop for anyone watching the channel and is the marker step 2 checks next run.

At the end of the run, give the user a one-line summary: signals found, drafted, skipped (already processed, already drafted, in a sequence, or not OGA), and needing attention (no HubSpot match, skip-list title, or no Gate Owner).

## Notes

- Never send or enroll. This skill writes properties; the HubSpot workflow and sequence do the rest.
- Influ2 history (multiple engagements, buying-group context) can inform which angle to lead with when the clicked ad is unclear, but none of it belongs in an email.
- If the rep asks to change their exclusion list later, update the config block and ask them to update the scheduled task's prompt with the new block (or offer to recreate the task).
- If a rep or Monica reports a factual problem in the copy, the fix belongs in the reference files so it applies to every rep.
